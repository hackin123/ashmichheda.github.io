# -*- coding: utf-8 -*-
"""
Created on Mon Nov 25 20:43:14 2019

@author: Abhishek
"""


import numpy as np
import matplotlib.pyplot as plt


N = 4
accuracy = (80.00,86.67,84,84)
ind = np.arange(N)    # the x locations for the groups
width = 0.35       # the width of the bars: can also be len(x) sequence

p1 = plt.bar(ind, accuracy, width)
plt.ylabel('Accuracy in Percentage(%)')
plt.title('Heart Disease Data set - Performance Analsis')
plt.xticks(ind, ('Naive Bayes', 'Decision Tree', 'KNN', 'Random Forest'))
plt.yticks(np.arange(0, 100, 5))

plt.show()